local turbo = require("turbo")
local moonbars = require("./moonbars")

local MoonbarsHandler = class("MoonbarsHandler", turbo.web.RequestHandler)
function MoonbarsHandler:post(...)
    local text = self.request.body

    local environment = moonbars.getEnvironment()
    function environment.print(...)
        for _, v in ipairs({...}) do
            self:write(tostring(v) .. "\t")
        end
        self:write("\n")
    end

    local success, result = moonbars.exec(text, environment)
    if success then
        self:set_status(200)
        self:write(tostring(result))
    else
        self:set_status(400)
        self:write(tostring(result))
    end
end

local application = turbo.web.Application({
    {"^/$", MoonbarsHandler}
})
application:listen(1337)

print("Server started on port 1337")
turbo.ioloop.instance():start()
