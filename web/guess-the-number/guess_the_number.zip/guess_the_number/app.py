from flask import Flask, render_template, session, redirect, url_for, request, flash
from os import urandom
import random
import base64

app = Flask(__name__)
app.secret_key = urandom(16)

flag = 'TUDCTF{redacted}'

@app.before_request
def before_request():
    if 'next_number' not in session:
        new_session()
        
@app.route('/')
def index():
    return render_template('index.html',
                           last_guess=session['last_guess'],
                           last_number=session['last_number'],
                           flag=flag)


@app.route('/guess', methods=["POST"])
def click():
    guess = request.form['guess']
    if guess:
        process_guess(int(guess))

    return redirect(url_for('index'))

previous_numbers = set()

def gen_random_number():
    num = random.randint(0, 2**52)
    # don't repeat numbers
    while num in previous_numbers:
        num = random.randint(0, 2**52)
    return num

key = gen_random_number()

def new_session():
    session['next_number'] = gen_random_number() ^ key
    session['last_guess'] = None
    session['last_number'] = None

def process_guess(guess):
    if guess in previous_numbers:
        guess = 0
    last_number = session['next_number'] ^ key
    session['last_number'] = last_number
    previous_numbers.add(last_number)
    session['next_number'] = gen_random_number() ^ key
    session['last_guess'] = guess
