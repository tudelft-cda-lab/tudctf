from flask import Flask, render_template, session, redirect, url_for, request, flash
from os import urandom
import random
import base64
from json import dumps

app = Flask(__name__)
app.secret_key = urandom(16)

flag = 'TUDCTF{redacted}'

verified_stroopwafels = {}

csrf_tokens = {}

@app.before_request
def before_request():
    if 'user_id' not in session:
        new_session()
        
@app.route('/')
def index():
    tokens = (random.getrandbits(2048), random.getrandbits(2048))
    csrf_tokens[session_hash(session)] = tokens

    return render_template('index.html',
                           stroopwafels=session['stroopwafels'],
                           money=session['money'],
                           csrf=tokens,
                           flag=(flag if session['money'] > 10 else None))


@app.route('/buy', methods=["POST"])
def buy():
    sh = session_hash(session)
    tokens = csrf_tokens.get(sh, None)
    if not tokens or str(tokens[0]) != request.form.get('csrf_token'):
        return render_template('msg.html', msg='CSRF token verification failed')
    del csrf_tokens[sh]

    money = session['money']
    if money < 3:
        return render_template('msg.html', msg='You don\'t have enough money!')

    session['money'] -= 3
    session['stroopwafels'] += 1
    verified_stroopwafels[session['user_id']] = verified_stroopwafels.get(session['user_id'], 0) + 1
    return redirect('/')


@app.route('/sell', methods=["POST"])
def sell():
    sh = session_hash(session)
    tokens = csrf_tokens.get(session_hash(session), None)
    if not tokens or str(tokens[1]) != request.form.get('csrf_token'):
        return render_template('msg.html', msg='CSRF token verification failed')
    del csrf_tokens[sh]

    money = session['money']
    if verified_stroopwafels.get(session['user_id'], 0) < 1:
        return render_template('msg.html', msg='You don\'t have any stroopwafels!')

    session['money'] += 3
    session['stroopwafels'] -= 1
    verified_stroopwafels[session['user_id']] -= verified_stroopwafels.get(session['user_id'], 0) - 1
    return redirect('/')

def new_session():
    session['user_id'] = random.getrandbits(64)
    session['money'] = 10
    session['stroopwafels'] = 0

def session_hash(sess):
    return dumps([sess['user_id'], sess['money'], sess['stroopwafels']], sort_keys=True)

